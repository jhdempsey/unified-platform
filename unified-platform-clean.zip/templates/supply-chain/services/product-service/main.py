"""
Product Service - FastAPI Application
REST API for managing data products
"""

import os
from typing import List, Optional
from datetime import datetime

from fastapi import FastAPI, Depends, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

import crud
import schemas
from database import get_db, init_db
from kafka_producer import get_event_producer
from models import DataProduct

from shared.config import config

# Create FastAPI app
app = FastAPI(
    title="Data Product Service",
    description="REST API for managing data products in the intelligent platform",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup_event():
    """Initialize database on startup"""
    print("🚀 Starting Product Service...")
    init_db()
    print("✅ Product Service ready")


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    print("👋 Shutting down Product Service...")
    producer = get_event_producer()
    producer.close()


@app.get("/", tags=["Root"])
async def root():
    """Root endpoint"""
    return {
        "service": "Data Product Service",
        "version": "1.0.0",
        "status": "running"
    }


@app.get("/health", response_model=schemas.HealthResponse, tags=["Health"])
async def health_check(db: Session = Depends(get_db)):
    """Health check endpoint"""
    try:
        # Test database
        db.execute("SELECT 1")
        db_status = "connected"
    except Exception:
        db_status = "disconnected"
    
    try:
        # Test Kafka (via producer)
        producer = get_event_producer()
        kafka_status = "connected" if producer else "disconnected"
    except Exception:
        kafka_status = "disconnected"
    
    return schemas.HealthResponse(
        status="healthy" if db_status == "connected" else "degraded",
        database=db_status,
        kafka=kafka_status
    )


@app.post(
    "/products",
    response_model=schemas.ProductResponse,
    status_code=status.HTTP_201_CREATED,
    tags=["Products"]
)
async def create_product(
    product: schemas.ProductCreate,
    db: Session = Depends(get_db)
):
    """
    Create a new data product
    
    Produces a ProductCreatedEvent to Kafka
    """
    try:
        # Create in database
        db_product = crud.create_product(db, product)
        
        # Produce event to Kafka
        producer = get_event_producer()
        producer.produce_product_created(db_product)
        producer.flush()
        
        return db_product
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create product: {str(e)}"
        )


@app.get(
    "/products",
    response_model=schemas.ProductList,
    tags=["Products"]
)
async def list_products(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    product_type: Optional[schemas.ProductType] = None,
    owner: Optional[str] = None,
    search: Optional[str] = None,
    tags: Optional[List[str]] = Query(None),
    db: Session = Depends(get_db)
):
    """
    List data products with optional filters
    
    - **skip**: Number of records to skip (pagination)
    - **limit**: Maximum records to return
    - **product_type**: Filter by product type
    - **owner**: Filter by owner
    - **search**: Search in name and description
    - **tags**: Filter by tags
    """
    products, total = crud.get_products(
        db,
        skip=skip,
        limit=limit,
        product_type=product_type,
        owner=owner,
        search=search,
        tags=tags
    )
    
    return schemas.ProductList(
        products=products,
        total=total,
        page=skip // limit + 1,
        page_size=limit
    )


@app.get(
    "/products/{product_id}",
    response_model=schemas.ProductResponse,
    tags=["Products"]
)
async def get_product(
    product_id: str,
    db: Session = Depends(get_db)
):
    """Get a specific data product by ID"""
    product = crud.get_product(db, product_id)
    
    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Product {product_id} not found"
        )
    
    return product


@app.put(
    "/products/{product_id}",
    response_model=schemas.ProductResponse,
    tags=["Products"]
)
async def update_product(
    product_id: str,
    product_update: schemas.ProductUpdate,
    db: Session = Depends(get_db)
):
    """
    Update a data product
    
    Produces a ProductUpdatedEvent to Kafka
    """
    product = crud.update_product(db, product_id, product_update)
    
    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Product {product_id} not found"
        )
    
    # Produce update event
    producer = get_event_producer()
    producer.produce_product_updated(product)
    producer.flush()
    
    return product


@app.delete(
    "/products/{product_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    tags=["Products"]
)
async def delete_product(
    product_id: str,
    db: Session = Depends(get_db)
):
    """Delete a data product"""
    deleted = crud.delete_product(db, product_id)
    
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Product {product_id} not found"
        )
    
    return None


@app.get("/products/topic/{topic}", response_model=List[schemas.ProductResponse], tags=["Products"])
async def get_products_by_topic(
    topic: str,
    db: Session = Depends(get_db)
):
    """Get all products associated with a Kafka topic"""
    products = crud.get_products_by_kafka_topic(db, topic)
    return products


@app.get("/stats", tags=["Statistics"])
async def get_stats(db: Session = Depends(get_db)):
    """Get product statistics"""
    return crud.get_product_stats(db)


if __name__ == "__main__":
    import uvicorn
    
    port = config.PRODUCT_SERVICE_PORT
    
    print(f"🚀 Starting Product Service on port {port}")
    print(f"📖 API docs: http://localhost:{port}/docs")
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=port,
        reload=True
    )