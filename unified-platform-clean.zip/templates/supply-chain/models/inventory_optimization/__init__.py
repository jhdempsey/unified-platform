"""Inventory Optimization Model."""
