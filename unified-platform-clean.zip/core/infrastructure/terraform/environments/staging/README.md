# Platform Infrastructure - Staging Environment

# TODO: Configure staging environment
# Copy from dev/ and adjust:
# - project_id = "platform-staging-..."
# - environment = "staging"
# - Adjust node counts, machine types as needed

# For now, staging is not yet configured
# When ready, copy dev/*.tf files here and modify variables
